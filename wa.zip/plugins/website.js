let handler = async m => {

let krtu = `web`
m.reply(`
> https://api.botcahx.eu.org
> https://tioprm.link

`.trim()) 
}
handler.command = /^(web)$/i

module.exports = handler
